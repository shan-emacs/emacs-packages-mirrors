## TODO

*With current progress estimates:*

* A set of heuristics to improve large-file incremental change handling (50%)
* Wisent LALR parser based on official PHP yacc parser automatically converted grammar (50%)
* Full integration with Emacs Semantic subsystem (30%)
* Approach flycheck about including support for this module by default (0%)
* Support indentation for HTML/XML, Javascript and CSS content inside inline_html content (0%)
* Eldoc support (0%)
* Flymake support (0%)
* PSR-2 auto-formatting tool based on lexer tokens (0%)
* Add to MELPA (0%)

[Back to start](../../../)
