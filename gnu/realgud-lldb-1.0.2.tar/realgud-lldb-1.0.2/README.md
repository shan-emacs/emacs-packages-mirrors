Emacs Lisp Module to add [lldb](https://lldb.llvm.org/) support to [realgud](http://github.com/rocky/emacs-dbgr).
