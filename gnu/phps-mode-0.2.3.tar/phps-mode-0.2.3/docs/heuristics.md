## Heuristics

These should solve the problem of freezing editor when making white-space changes to code.

* When pressing return when line after cursor is only white-space
* When pressing backspace when line before cursor is only white-space

[Back to start](../../../)
