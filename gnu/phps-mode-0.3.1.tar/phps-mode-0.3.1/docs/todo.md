## TODO

*With current progress estimates:*

* Add to MELPA package archive (50%)
* A set of heuristics to improve large-file incremental change handling (75%)
* Wisent LALR parser based on official PHP yacc parser automatically converted grammar (50%)
* mmm-mode support (50%)
* Full integration with Emacs Semantic subsystem (30%)
* Eldoc support (0%)
* Flymake support (0%)
* PSR-2 auto-formatting tool based on lexer tokens (0%)

[Back to start](../../../)
