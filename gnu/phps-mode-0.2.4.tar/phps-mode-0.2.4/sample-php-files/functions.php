<?php

/**
 * @param string $myArg1
 * @param string $myArg2
 

 
 */
function myFunctionA($myArg1, $myArg2)
{
    $myArg1 = true;
    $myArg2 = false;
    echo "some stuff";
}

function myFunctionB($myArg3) {
    echo 'something';
}

?>
<body>
    <div>
        <strong>Hello</strong>
        <p>
            More stuff
        </p>
    </div>
</body>