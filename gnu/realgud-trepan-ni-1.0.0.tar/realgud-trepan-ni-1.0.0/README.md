Module to add [trepan-ni](https://github.com/rocky/trepan-ni) support
using nodejs'
[V8-inspector-protocol](https://chromedevtools.github.io/devtools-protocol/v8/Debugger)
debugger support to emacs
[realgud](http://github.com/realgud/realgud).
