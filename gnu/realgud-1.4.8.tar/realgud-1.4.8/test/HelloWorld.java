public class HelloWorld {
    public static void main(String[] args) {
	String msg = "Hello, World!";
        System.out.println(msg); // Display the string.
    }
}
