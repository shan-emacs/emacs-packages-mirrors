* When pressing return when line after cursor is only white-space
* When pressing backspace when line before cursor is only white-space
