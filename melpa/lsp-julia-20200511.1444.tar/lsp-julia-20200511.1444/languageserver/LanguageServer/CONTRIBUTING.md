By contributing code to LanguageServer.jl, you are agreeing to release that code under the [MIT License](https://github.com/julia-vscode/LanguageServer.jl/blob/master/LICENSE).
