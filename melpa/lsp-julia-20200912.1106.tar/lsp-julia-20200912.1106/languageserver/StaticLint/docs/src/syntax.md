# Syntax Reference

```@index
Modules = [StaticLint]
Pages   = ["syntax.md"]
```

## Main

```@autodocs
Modules = [StaticLint]
Pages   = readdir("../src")
```

## Linting

```@autodocs
Modules = [StaticLint]
Pages   = readdir("../src/linting")
```
