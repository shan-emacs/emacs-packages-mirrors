# Syntax Reference

```@index
Modules = [LanguageServer]
Pages   = ["syntax.md"]
```

## Main
```@autodocs
Modules = [LanguageServer]
Pages   = readdir("../src")
```

## Requests
```@autodocs
Modules = [LanguageServer]
Pages   = readdir("../src/requests")
```

## Protocol
```@autodocs
Modules = [LanguageServer]
Pages   = readdir("../src/protocol")
```
