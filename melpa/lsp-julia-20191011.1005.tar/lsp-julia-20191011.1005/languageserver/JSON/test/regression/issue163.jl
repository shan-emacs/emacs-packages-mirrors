@test Float32(JSON.parse(json(2.1f-8))) == 2.1f-8
